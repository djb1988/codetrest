require "application_system_test_case"

class PicturesTest < ApplicationSystemTestCase
  # test "visiting the index" do
  #   visit pictures_url
  #
  #   assert_selector "h1", text: "Picture"
  # end
end
