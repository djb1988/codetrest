class Comment < ApplicationRecord
  belongs_to :picture
end
