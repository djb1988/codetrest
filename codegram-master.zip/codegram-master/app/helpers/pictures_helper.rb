module PicturesHelper
end
